	//实例化编辑器
	//建议使用工厂方法getEditor创建和引用编辑器实例，如果在某个闭包下引用该编辑器，直接调用UE.getEditor('editor')就能拿到相关的实例
	var ue = UE.getEditor('editor',{
    		elementPathEnabled:false
    	});
	//为数组添加一个自定义方法，用于移除数组的任意一个元素
	Array.prototype.remove=function(dx){ 
		if(isNaN(dx)||dx>=this.length){return false;} 
		for(var i=0,n=0;i<this.length;i++) 
		{ 
			if(this[i]!=this[dx]) 
			{ 
				this[n++]=this[i]; 
			} 
		} 
		this.length-=1; 
	}; 
	
	var count = 1,//设置添加div的索引变量
	serTimeValue = 0,//setTimeout函数的返回参数，用于取消setTimeout的执行
	imgURL = new Array(),//上传图像的URL地址
	editObj,//当前编辑的图文消息对象
	newsData = {"articles" : []};//多图文消息集合

	//单条图文消息对象
	function newData(){
		this.title = "",
		this.author = "",
		this.thumb_media_id = "",
		this.content = "",
		this.show_cover_pic = 0,//0为不显示，1为显示
		this.digest = "",
		this.content_source_url = "";
	}
	$(function(){
		//建立一个默认图文消息的对象
		newsData.articles[0] = new newData();
		//将默认图文消息对象设置为当前编辑的数据对象
		editObj = newsData.articles[0];
		//为toast-container提示框绑定一个关闭按钮的点击事件
		$(".toast-close-button").bind("click",function(){
			//隐藏提示框
			$('#toast-container').hide(500);
			//取消setTimeout函数的执行，否则会发生事件的冒泡现象
			clearTimeout(serTimeValue);
		});
		//设置添加事件，当点击添加消息按钮的时候为页面添加一个图文添加框
		$(".editor-add").click(function(){
			//检索图文消息的div个数若超出限制弹出提示框提示
			var countDiv = $("div[id^=msg-item]").length;
			if(countDiv==8){
				//当图文div数量满足最大数量限制的时候，需要弹出提示框，当提示框隐藏的时候执行显示函数，并在5秒后在此隐藏
				var promptDiv = $("#toast-container");
				$(".toast-title").text("最多添加8篇图文");
				//此处的样式判断是为了防止多次点击发生显示错误
				if(promptDiv.css("display")=='none'){
					promptDiv.show(500);
					serTimeValue = setTimeout("$('#toast-container').hide(500)",5000);
				}
			}else{
				//添加图文添加框
				$(".preview-items").append(function (){
					var str = "<div class='msg-item editing' id='msg-item_"+count+"' onclick='selectEdit(this)'>"
								   +"<img class='cover' src=''>"
								   +"<span class='cover-empty-tips'>缩略图</span>"
								   +"<h4 id='cover-title'></h4>"
								   +"<div class='operate'>"
								   +"	<i class='fa fa-eye'></i>"
								   +"	<i class='fa fa-pencil'></i>"
								   +"	<i class='fa fa-trash' onclick=\"deleteEdit(this)\"></i>"
								   +"</div>"
								   +"<noscript></noscript>"
							+"</div>";
					//获取当前图文消息数组长度，可作为新建立的图文消息对象的索引
					var index = newsData.articles.length;
					//创建新的图文消息对象并放到图文消息数组当中
					newsData.articles[index] = new newData();
					//将新创建的对象设置为当前编辑的图文数据对象
					editObj = newsData.articles[index];
					return str;
				});
				//改变其他未被编辑的图文消息框的class参数
				$.each($("#msg-item_"+count).siblings(".msg-item"),function(){
					$(this).attr("class","msg-item");
				});
				//设定选中图标选中此添加框
				var offset = $(".editing").offset();
				$(".active-arrow").css("top",offset.top+12);
				//重新设定图片上传提示
				$(".img-text").html("<span>（</span><span>小图片建议尺寸：200像素*200像素 格式：png、gif、jpg</span><span>）</span>");
				//隐藏摘要文本域
				$("#abstract").hide();
				//获取到新添加的图文消息编辑框，并选中它
				var obj = $("#msg-item_"+count)[0];
				selectEdit(obj);
				//添加框索引自增
				count++;
			}
		});
		//当点击上传按钮的时候为<input file>标签绑定一个change事件
		$("#uploadBtn").click(function(){
			$("#cover_file").off("change",uploadImg);
			$("#cover_file").on("change",uploadImg);
		});
		//jquery实现input输入框实时输入触发事件，使标题在输入的时候能够实时同步到图文消息DIV
		$("#form-title").bind('input propertychange',
			function(){
				$(".editing").children("#cover-title").text(this.value);
				//记录标题内容
				editObj.title = this.value;
			});
		$("#form-author").bind('input propertychange',
			function(){
				//记录作者
				editObj.author = this.value;
			});
		$("#form-abstract").bind('input propertychange',
			function(){
				//记录摘要
				editObj.digest = this.value;
			});
		$("#form-url").bind('input propertychange',
			function(){
				//记录原文链接
				editObj.content_source_url = this.value;
			});
		//百度编辑器，监听编辑器内容改变
		ue.addListener("contentChange",function(){
				editObj.content = ue.getContent();
        });
		//提交事件
		$("#subBtn").click(function(){
			var data = {"req":JSON.stringify(newsData)};//注意AJAX不能传递就是对象，只能传递字符串
			var url = "http://localhost/wx/message/addNews";
			$.post(url,data,function(data){
				alert(data);
			});
		});
	});
	//封面是否显示在正文
	function checkCover(obj){
		var jObj = $(obj);
		if(editObj.show_cover_pic==0){
			editObj.show_cover_pic = 1;
			jObj.removeClass("fa-square-o");
			jObj.addClass("fa-check-square-o");
		}else{
			editObj.show_cover_pic = 0;
			jObj.removeClass("fa-check-square-o");
			jObj.addClass("fa-square-o");
		}
	}
	//上传图片方法
	function uploadImg(){
		//当点击上传图片后，调用AJAX将图片提交后台，此时显示出进度条，当上传成功后
		//在显示出如下的HTML代码将图片展示出来
		$(".form-cover").append("<div min='0' max='100' class='progress'> "
				+"<div id='progress' min='0' max='100' class='progress-bar progress-bar-success progress-bar-striped' "
				+"role='progressbar' aria-valuemin='0' "
				+"aria-valuemax='100' >"
				+"</div>"
			+"</div>"
		);
		uploadFile();
	};
	//图文添加框点击时所执行的方法
	function selectEdit(obj){
		//获取点击的图文消息编辑框的位置索引
		var divIndex = $(obj).index();
		//将次点击的图文消息框所对应的图文消息对象设定为当前编辑的图文消息对象
		editObj = newsData.articles[divIndex];
		/*更新当前图文消息页面所编辑的数据*/
		//更新标题
		$("#form-title").val(editObj.title);
		//更新作者
		$("#form-author").val(editObj.author);
		//更新封面是否显示在正文
		if(editObj.show_cover_pic==0){
			$("#check_Box").removeClass("fa-check-square-o");
			$("#check_Box").addClass("fa-square-o");
		}else{
			$("#check_Box").removeClass("fa-square-o");
			$("#check_Box").addClass("fa-check-square-o");
		}
		//更新摘要
		$("#form-abstract").val(editObj.digest);
		//更新编辑器内容
		ue.setContent(editObj.content);
		//更新原文连接
		$("#form-url").val(editObj.content_source_url);
		//更新上传图片
		if(editObj.thumb_media_id == ""){
			$(".upload-preview-wrap").remove();
		}else{
			$(".upload-preview-wrap").remove();
			$(".form-cover").append(
					"<div class='upload-preview-wrap clearfix'>"
						+"<img class='upload-preview-img' src="+imgURL[divIndex]+" alt=''>"
						+"<a href='javascript:void(0);' onclick='removeImgDiv()'>删除</a>"
						+"<noscript></noscript>"
					+"</div>"
				);
		}
		//重新设置图文添加框的选中图标的位置
		var domId = obj.getAttribute("id");
		var offset = $(obj).offset();
		//获取第一个图文添加框的DIV对象，并获取其id属性
		var firstDiv = $(".preview-items").children()[0];
		var firId = firstDiv.getAttribute("id");
		//判断当前点击对象是否为第一个图文添加框对象
		if(domId == firId){
			//第一个图文添加框的处理方式
			$(".active-arrow").css("top",offset.top+72);
			//第一个图文添加框的图片上传提示
			$(".img-text").html("<span>（</span><span> 大图片建议尺寸：900像素*500像素 格式：png、gif、jpg</span><span>）</span>");
			//显示摘要文本域
			$("#abstract").show();
		}else{
			//其余图文添加框的处理方式
			$(".active-arrow").css("top",offset.top+12);
			//其余图文添加框的图片上传提示
			$(".img-text").html("<span>（</span><span> 小图片建议尺寸：200像素*200像素 格式：png、gif、jpg</span><span>）</span>");
			//隐藏摘要文本域
			$("#abstract").hide();
		}
		//重新设置所有图文添加框的class属性值
		$(obj).attr("class","msg-item editing");
		$.each($(obj).siblings(".msg-item"),function(){
			$(this).attr("class","msg-item");
		});
		return false;
	}
	//删除前的 提示/校验 方法
	function deleteEdit(obj){
		//获取preview-items DIV的子元素div个数（图文消息框的个数）
		var editDivs = $(".preview-items").children();
		var divCount = editDivs.length;
		//如果只剩下一个，那么弹出提示框，并且不再删除DIV
		if(divCount==1){
			var promptDiv = $("#toast-container");
			$(".toast-title").text("至少保留一条图文消息");
			if(promptDiv.css("display")=='none'){
				promptDiv.show(500);
				serTimeValue = setTimeout("$('#toast-container').hide(500)",5000);
			}
		//若图文消息DIV数量大于一，那么提供删除功能
		}else{
			//获取到点击的图文消息编辑框的Dome对象
			var objDiv = obj.parentNode.parentNode;
			//获取次此div的索引
			var divIndex = $(objDiv).index();
			removeModleDiv(objDiv,divIndex);
		}
	}
	//删除提示模板
	function removeModleDiv(obj_,index){
		var str = $(obj_).attr("id");
		//获取浮动层对象，并将其显示出来
		var obj = $(".modal-scrollable");
		$(".modal-backdrop").css("display","block");
		obj.css("display","block");
		//向模板中插入html代码
		obj.html(
			'<div class="modal-dialog">'
				+'<div class="modal-content" role="document">'
					+'<div aria-label="Close" class="modal-header">'
						+'<button class="close">'
						+'	<span aria-hidden="true" onclick="reomveModalScrollable()">×</span>'
						+'</button>'
						+'<h4 class="modal-title">提示</h4>'
					+'</div>'
					+'<div class="modal-body">是否确定删除？</div>'
					+'<div class="modal-footer">'
					+'	<button class="btn btn-primary" onclick="removeEditDiv(\'#'+str+'\','+index+')">确定</button>'
					+'	<button class="btn btn-default" onclick="reomveModalScrollable()">关闭</button>'
					+'</div>'
				+'</div>'
			+'</div>'
		);
	}
	//取消删除隐藏浮动层DIV的方法
	function reomveModalScrollable(){
		//清空浮动层DIV的html元素
		$(".modal-scrollable").html();
		//隐藏浮动层DIV
		$(".modal-backdrop").css("display","none");
		$(".modal-scrollable").css("display","none");
	}
	//删除图文消息DIV的方法
	function removeEditDiv(str,index){
		//移除要删除的图文消息框对应的图文数据对象
		newsData.articles.remove(index);
		//清空图文消息对应的封面URL数据
		var divIndex = $(".editing").index();
		imgURL.remove(divIndex);
		//如果存在上传图片的展示框，将其删除
		if($(".upload-preview-wrap")){
			$(".upload-preview-wrap").remove();
		}
		//清空被删除的DIV元素
		$(str).empty();
		$(str).remove();
		//隐藏浮动层DIV
		$(".modal-backdrop").css("display","none");
		$(".modal-scrollable").css("display","none");
		//获取第一个图文消息框，并且将其class置为编辑模式，然后将指示图标指向它
		var firstEdit = $("div[id^=msg-item]")[0];
		$(firstEdit).attr("class","msg-item editing");
		//将当前编辑的数据对象设置为默认图文消息对象
		editObj = newsData.articles[0];
		if(editObj.thumb_media_id != ""){
			$(".form-cover").append(
					"<div class='upload-preview-wrap clearfix'>"
						+"<img class='upload-preview-img' src="+imgURL[0]+" alt=''>"
						+"<a href='javascript:void(0);' onclick='removeImgDiv()'>删除</a>"
						+"<noscript></noscript>"
					+"</div>"
				);
		}
		var offset = $(".editing").offset();
		$(".active-arrow").css("top",offset.top+72);
		//显示摘要文本域
		$("#abstract").show();
	}
	//上传文件方法
   function uploadFile(){
	  var fileUpload = $("#cover_file").get(0).files[0];
	  if(fileUpload){
		  var fileSize = 0;
		  //判断上传图片的大小是否超出限制
		  //如果超出限制
		  if (fileUpload.size > 2*1024 * 1024){
			  //将进度条DIV移除
			  $(".progress").remove();
			  //解绑change事件防止清空value时的冒泡事件
			  $("#cover_file").off("change",uploadImg);
			  //清空input file D的value
			  $("#cover_file").val("");
			  //弹出提示框
			  var promptDiv = $("#toast-container");
			  $(".toast-title").text("上传图片过大，不能超过2M");
			  if(promptDiv.css("display")=='none'){
				  promptDiv.show(500);
				  serTimeValue = setTimeout("$('#toast-container').hide(500)",5000);
			  }
		  }else{
			  var formData = new FormData();
			  formData.append("file" , fileUpload);
			  /** 
			   * 必须false才会避开jQuery对 formdata 的默认处理 
			   * XMLHttpRequest会对 formdata 进行正确的处理 
			   */
			  $.ajax({
				  type: "POST",
				  url: "http://localhost/wx/message/upLoad",
				  data: formData ,
				  processData : false, 
				  //必须false才会自动加上正确的Content-Type 
				  contentType : false , 
				  xhr: function(){
					var xhr = $.ajaxSettings.xhr();
					if(onprogress && xhr.upload) {
						xhr.upload.addEventListener("progress" , onprogress, false);
						xhr.addEventListener("load", uploadComplete, false);
						xhr.addEventListener("error", uploadFailed, false);
						xhr.addEventListener("abort", uploadCanceled, false);
						return xhr;
					}
				  }
			 });
		  }
	  }  
	}
	 /**
	  * 侦查附件上传情况 ,这个方法大概0.05-0.1秒执行一次
	  */
	 function onprogress(evt){
	  var loaded = evt.loaded;     //已经上传大小情况 
	  var tot = evt.total;      //附件总大小 
	  var per = Math.floor(100*loaded/tot);  //已经上传的百分比 
	  $("#progress").css("width" , per +"%");

	  if(per == 100){
		  /* 监听获取CSS完成过渡事件transitionend! */
			var transitionEvent = whichTransitionEvent();
			transitionEvent && $("#progress")[0].addEventListener(transitionEvent, function() {
				$(".progress").remove();
				//获取当前编辑的图文消息DIV索引，用来从获取封面URL数组中此图文消息对应的封面URL（索引相对应）
				var index = $(".editing").index();
				$(".form-cover").append(
					"<div class='upload-preview-wrap clearfix'>"
						+"<img class='upload-preview-img' src="+imgURL[index]+" alt=''>"
						+"<a href='javascript:void(0);' onclick='removeImgDiv()'>删除</a>"
						+"<noscript></noscript>"
					+"</div>"
				);
			});
		}
	 }

   function uploadComplete(evt) {
	 //响应完成获取上传图片URL
	 var jsonResponse = evt.target.responseText;
	 var jsonObject = eval("("+jsonResponse+")");
	//获取当前编辑的图文消息DIV索引，用来从获取封面URL数组中此图文消息对应的封面URL（索引相对应）
	 var index = $(".editing").index();
	 //将响应得到的封面URL存到封面URL数组
	 imgURL[index] = jsonObject.imgPath;
	 editObj.thumb_media_id = jsonObject.media_id;
	 var imgObj = $(".editing").children(".cover")[0];
	 $(imgObj).attr("src",jsonObject.imgPath);
	 $(".upload-preview-img").attr("src",jsonObject.imgPath);
   }

   function uploadFailed(evt) {
	 alert("There was an error attempting to upload the file.");
   }

   function uploadCanceled(evt) {
	 alert("The upload has been canceled by the user or the browser dropped the connection.");
   }
   //删除上传图片
   function removeImgDiv(){
		//移除展示DIV
		$(".upload-preview-wrap").remove();
		//获取当前编辑的图文消息DIV索引，用来从获取封面URL数组中此图文消息对应的封面URL（索引相对应）
		var index = $(".editing").index();
		//移除封面URL数据
		imgURL.remove(index);
		//取消<input file>的改变事件
		$("#cover_file").off("change",uploadImg);
		//清空<input file>的值
		$("#cover_file").val("");
		//清空图文消息框图片
		$(".editing").children(".cover").attr("src","");
   }

   /* 定义CSS完成过渡触发事件transitionend ，并根据浏览器种类返回对应的事件 */
	function whichTransitionEvent(){
		var t;
		var el = document.createElement('fakeelement');
		var transitions = {
		  'transition':'transitionend',
		  'OTransition':'oTransitionEnd',
		  'MozTransition':'transitionend',
		  'WebkitTransition':'webkitTransitionEnd'
		}

		for(t in transitions){
			if( el.style[t] !== undefined ){
				return transitions[t];
			}
		}
	}

