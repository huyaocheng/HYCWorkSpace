/**
 * ΢����Ϣ��Ӧ������
 * 
 * @author hyc
 */
package com.huiyuan.weixin.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.huiyuan.weixin.pojo.servermessage.ImageMessage;
import com.huiyuan.weixin.pojo.servermessage.MusicMessage;
import com.huiyuan.weixin.pojo.servermessage.NewsMessage;
import com.huiyuan.weixin.pojo.servermessage.TextMessage;
import com.huiyuan.weixin.pojo.servermessage.VideoMessage;
import com.huiyuan.weixin.pojo.servermessage.VoiceMessage;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.core.util.QuickWriter;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.io.xml.PrettyPrintWriter;
import com.thoughtworks.xstream.io.xml.XppDriver;

public class WxMessageUtil {
	 /** 
     * һ���������� 
     *  
     * @param element 
     *            : org.jdom.Element 
     * @return java.util.Map ʵ�� 
     */  
    @SuppressWarnings("unchecked")  
    private static Map<String, List>  iterateElement(Element element) {  
        List jiedian = element.elements();  
        Element et = null;  
        Map obj = new HashMap();  
        List list = null;  
        for (int i = 0; i < jiedian.size(); i++) {  
            list = new LinkedList();  
            et = (Element) jiedian.get(i);  
            if (et.getTextTrim().equals("")) {  
                if (et.elements().size() == 0)  
                    continue;  
                if (obj.containsKey(et.getName())) {  
                    list = (List) obj.get(et.getName());  
                }  
                list.add(iterateElement(et));  
                obj.put(et.getName(), list);  
            } else {  
                if (obj.containsKey(et.getName())) {  
                    list = (List) obj.get(et.getName());  
                }  
                list.add(et.getTextTrim());  
                obj.put(et.getName(), list);  
            }  
        }  
        return obj;  
    }
	/**
	 * ����΢�ŷ�����XML���󲢱��浽map��
	 * @param request 
	 * @return Map<String,Object> ���ص�map
	 * @throws IOException
	 * @throws DocumentException
	 */
	public static Map<String,List> parseXml(String XML) {
		//���ڴ�Ž�������
		Map<String,Object> map = new HashMap<String,Object>();
		InputStream input = null;
		Document doc = null;
		try {
			//��request��ȡ��������
			//��ȡ������
			doc = DocumentHelper.parseText(XML);
		} catch (DocumentException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} 
		//�õ�XML��Ԫ��
		Element root = doc.getRootElement();
		//�õ���Ԫ�ص������ӽڵ�
		List<Element> elements = root.elements();
		
		//����Ȼ�����map
		/*for(Element e : elements){
			map.put(e.getName(), e.getText());
		}*/
		//test(elements, map);
		map.put(root.getName(), iterateElement(root));
		//�ͷ���Դ
		try {
			if(input!=null) input.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		input = null;
		return (HashMap<String,List>)map.get("xml");
	}
	
	 // ������xml�ڵ��ת��������CDATA���
	private static XStream xstream = new XStream(new XppDriver() {
	    public HierarchicalStreamWriter createWriter(Writer out) {
		    return new PrettyPrintWriter(out) {
		        boolean cdata = true;
		        @SuppressWarnings("unchecked")
		        public void startNode(String name, Class clazz) {
			        super.startNode(name, clazz);
		        }
		        protected void writeText(QuickWriter writer, String text) {
		            if (cdata) {
		                writer.write("<![CDATA[");
		                writer.write(text);
		                writer.write("]]>");
		            } else {
			            writer.write(text);
		            }
		        }
		    };
	    }
	});
	
	/**
	 * �ı���Ϣ����ת����XML
	 * @param textMessage �ı���Ϣ����
	 * @return xml��ʽ�ַ���
	 */
	public static String messageToXml(TextMessage textMessage){
		xstream.alias("xml", textMessage.getClass());
		return xstream.toXML(textMessage);
	}
	
	/**
	 * ͼƬ��Ϣ����ת����XML
	 * @param imageMessage ͼƬ��Ϣ����
	 * @return xml��ʽ�ַ���
	 */
	public static String messageToXml(ImageMessage imageMessage){
		xstream.alias("xml", imageMessage.getClass());
		return xstream.toXML(imageMessage);
	}
	
	/**
	 * ������Ϣ����ת����XML
	 * @param voiceMessage ������Ϣ����
	 * @return xml��ʽ�ַ���
	 */
	public static String messageToXml(VoiceMessage voiceMessage){
		xstream.alias("xml", voiceMessage.getClass());
		return xstream.toXML(voiceMessage);
	}
	
	/**
	 * ��Ƶ��Ϣ����ת����XML
	 * @param videoMessage ��Ƶ��Ϣ����
	 * @return xml��ʽ�ַ���
	 */
	public static String messageToXml(VideoMessage videoMessage){
		xstream.alias("xml", videoMessage.getClass());
		return xstream.toXML(videoMessage);
	}
	
	/**
	 * ������Ϣ����ת����XML
	 * @param musicMessage �ı���Ϣ����
	 * @return xml��ʽ�ַ���
	 */
	public static String messageToXml(MusicMessage musicMessage){
		xstream.alias("xml", musicMessage.getClass());
		return xstream.toXML(musicMessage);
	}
	
	/**
	 * ͼ����Ϣ����ת����XML
	 * @param newsMessage ͼ����Ϣ����
	 * @return xml��ʽ�ַ���
	 */
	public static String messageToXml(NewsMessage newsMessage){
		xstream.alias("xml", newsMessage.getClass());
		return xstream.toXML(newsMessage);
	}
	
}
