/**
 * ΢�Ų˵�������
 * 
 * @author hyc
 */
package com.huiyuan.weixin.util;

import org.apache.log4j.Logger;

import net.sf.json.JSONObject;

import com.huiyuan.core.util.HttpsUtil;
import com.huiyuan.weixin.pojo.Menu.Menu;

public class WxMenuUtil {
	private static Logger log = Logger.getLogger(WxMenuUtil.class);
	/**
	 * �����˵�
	 * @param menu �˵�ʵ��
	 * @param accessToken �ӿڵ���ƾ֤
	 * @return true �ɹ� false ʧ��
	 */
	public static boolean createMenu(Menu menu, String accessToken){
		boolean result = false;
		String requestUrl = WxGlobal.MENU_CREATE_INTERFACE.replace("ACCESS_TOKEN", accessToken);
		//������ת����JSON��
		String jsonMenu = JSONObject.fromObject(menu).toString();
		
		//System.out.println(jsonMenu);
		//����post���󴴽��˵�
		JSONObject jsonObject = HttpsUtil.httpsRequest(requestUrl, "POST", jsonMenu);
		
		if(null != jsonObject){
			int errorCode = jsonObject.getInt("errcode");
			String errorMsg = jsonObject.getString("errmsg");
			if(0 == errorCode){
				result = true;
			}else{
				result = false;
				log.error("�����˵�ʧ�� errcode:{ "+errorCode+" } errmsg:{ "+errorMsg+" }");
			}
			//System.out.println(jsonObject.toString());
		}
		return result;
	}
	
	/**
	 * ��ѯ�˵�
	 * @param accessToken
	 * @return �˵�json��
	 */
	public static String getMenu(String accessToken){
		String result = null;
		String requestUrl = WxGlobal.MENU_SELECT_INTERFACE.replace("ACCESS_TOKEN", accessToken);
		//����get����ɾ���˵�
		JSONObject jsonObject = HttpsUtil.httpsRequest(requestUrl, "GET", null);
		
		if(null != jsonObject){
			result = jsonObject.toString();
		}
		return result;
	}
	
	/**
	 * ɾ���˵�
	 * @param accessToken
	 * @return true �ɹ� false ʧ��
	 */
	public static boolean deleteMenu(String accessToken){
		boolean result = false;
		String requestUrl = WxGlobal.MENU_DELETE_INTERFACE.replace("ACCESS_TOKEN", accessToken);
		//����get����ɾ���˵�
		JSONObject jsonObject = HttpsUtil.httpsRequest(requestUrl, "GET", null);
		
		if(null != jsonObject){
			int errorCode = jsonObject.getInt("errcode");
			String errorMsg = jsonObject.getString("errmsg");
			if(0 == errorCode){
				result = true;
			}else{
				result = false;
				log.error("ɾ���˵�ʧ�� errcode:{ "+errorCode+" } errmsg:{ "+errorMsg+" }");
			}
		}
		return result;
	}
}
