package com.huiyuan.weixin.util;

import net.sf.json.JSONObject;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huiyuan.core.util.HttpsUtil;
import com.huiyuan.core.util.PropertiesTools;
import com.huiyuan.core.util.Tools;

public class WxInterfaceUtil {
	private static Logger log = Logger.getLogger(WxInterfaceUtil.class);
	/**
	 * ��ȡ�ӿڷ���ƾ֤access_token
	 * 
	 * @param appid
	 *            ƾ֤
	 * @param appsecret
	 *            ��Կ
	 */
	public static void getAccess_token(String appid, String appsecret) {
		// ƾ֤��ȡ(GET)
		String token_url = WxGlobal.GET_ACCESS_TOKEN_INTERFACE;
		String requestUrl = token_url.replace("APPID", appid).replace(
				"APPSECRET", appsecret);
		JSONObject jsonObject = HttpsUtil.httpsRequest(requestUrl, "GET", null);
		String access_token = null;
		if (null != jsonObject) {
			try {
				access_token = jsonObject.getString("access_token");
				PropertiesTools.updateProperties("access_token",access_token);
				System.out.println(access_token);
			} catch (Exception e) {
				// ��ȡtokenʧ��
				log.error("��ȡaccess_tokenʧ�� errcode:{} errmsg:{}"+jsonObject.getInt("errcode")+jsonObject.getString("errmsg"));
			}
		}
	}
	
	/**
	 * ��weixinRequest.properties�ļ���ȡ��accessToken
	 * @return accessToken
	 */
	public static String getAccessToken(){
		return PropertiesTools.getKeyValue("access_token");
	}
	
	/**
	 * �����е�accessTokenʧЧʱ�����¸�λaccessToken���ٴδ�weixinRequest.properties�ļ���ȡ��accessToken
	 * @return accessToken
	 */
	public static String resetAccesstoken(){
		WxInterfaceUtil.getAccess_token(PropertiesTools.getKeyValue("appID"), PropertiesTools.getKeyValue("appsecret"));
		return PropertiesTools.getKeyValue("access_token");
	}
}
