/**
 * ΢����֤У�鹤����
 * @author hyc
 */
package com.huiyuan.weixin.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class WxCheckTools {
	private static String token = "weixintest2016";
	public static boolean checkSignauer(String signature, String timestamp, String nonce){
		String[] str = new String[]{token,timestamp,nonce};
		Arrays.sort(str);
		
		StringBuffer buff = new StringBuffer();
		for(int i=0;i<str.length;i++){
			buff.append(str[i]);
		}
		
		MessageDigest md = null;
		String result = null;
		try {
			md = MessageDigest.getInstance("SHA-1");
			byte[] digest = md.digest(buff.toString().getBytes());
			result = bytesToStr(digest);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result!=null?result.equals(signature.toUpperCase()):false;
	}
	
	public static String bytesToStr(byte[] digest){
		String strDigest = "";
		for(int i=0;i<digest.length;i++){
			strDigest += byteToHexStr(digest[i]);
		}
		return strDigest;
	}
	
	public static String byteToHexStr(byte b){
		char [] Digit = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
		char[] tempArr = new char[2];
		tempArr[0] = Digit[(b>>>4)&0x0F];
		tempArr[1] = Digit[b&0x0F];
		String s = new String(tempArr);
		return s;
	}
}
