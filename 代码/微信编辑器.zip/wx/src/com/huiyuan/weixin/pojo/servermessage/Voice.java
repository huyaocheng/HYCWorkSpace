/**
 * ����modle
 * 
 * @author hyc
 */
package com.huiyuan.weixin.pojo.servermessage;

public class Voice {
	//ý���ļ�ID
	private String MediaId;

	public String getMediaId() {
		return MediaId;
	}

	public void setMediaId(String mediaId) {
		MediaId = mediaId;
	}
	
}
