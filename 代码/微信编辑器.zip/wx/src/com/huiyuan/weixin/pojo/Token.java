/**
 * �ӿڵ���ƾ֤
 * 
 * @author hyc
 */
package com.huiyuan.weixin.pojo;

public class Token {
	//�ӿڷ���ƾ֤
	private String accessToken;
	//ƾ֤��Чʱ������
	private int expriesIn;
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public int getExpriesIn() {
		return expriesIn;
	}
	public void setExpriesIn(int expriesIn) {
		this.expriesIn = expriesIn;
	}
	
}
