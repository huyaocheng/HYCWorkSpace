/**
 * ��Ӧ������Ϣ��
 * 
 * @author hyc
 */
package com.huiyuan.weixin.pojo.servermessage;

public class MusicMessage {
	//����
	private Music music;

	public Music getMusic() {
		return music;
	}

	public void setMusic(Music music) {
		this.music = music;
	}
	
}
