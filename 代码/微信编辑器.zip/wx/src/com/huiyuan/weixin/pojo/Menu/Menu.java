/**
 * �˵���װ��
 * 
 * @author hyc
 */
package com.huiyuan.weixin.pojo.Menu;

public class Menu {
	private Button[] button;

	public Button[] getButton() {
		return button;
	}

	public void setButton(Button[] button) {
		this.button = button;
	}
	
	
}
