/**
 * ������Ϣ�Ļ�����
 * 
 * @author hyc
 * @date 2016-3-16
 */
package com.huiyuan.weixin.pojo.clientmessage;

public class BaseMessage {
	//������΢�ź�
	private String ToUserName;
	//���ͷ�OpenId
	private String FromUserName;
	//��Ϣ����ʱ��
	private long CreateTime;
	//������Ϣ����(text/image/location/link/voice)
	private String MsgType;
	//��ϢID��64λ����
	private long MsgId;
	
	public String getToUserName() {
		return ToUserName;
	}
	public void setToUserName(String toUserName) {
		ToUserName = toUserName;
	}
	public String getFromUserName() {
		return FromUserName;
	}
	public void setFromUserName(String fromUserName) {
		FromUserName = fromUserName;
	}
	public long getCreateTime() {
		return CreateTime;
	}
	public void setCreateTime(long createTime) {
		CreateTime = createTime;
	}
	public String getMsgType() {
		return MsgType;
	}
	public void setMsgType(String msgType) {
		MsgType = msgType;
	}
	public long getMsgId() {
		return MsgId;
	}
	public void setMsgId(long msgId) {
		MsgId = msgId;
	}
	
}
