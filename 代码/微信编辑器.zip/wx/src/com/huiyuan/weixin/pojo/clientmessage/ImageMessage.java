/**
 * ͼƬ��Ϣ��
 * 
 * @author hyc
 */
package com.huiyuan.weixin.pojo.clientmessage;

public class ImageMessage extends BaseMessage{
	//ͼƬ����
	private String PicUrl;

	public String getPicUrl() {
		return PicUrl;
	}

	public void setPicUrl(String picUrl) {
		PicUrl = picUrl;
	}
	
	
}
