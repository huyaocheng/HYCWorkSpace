/**
 * ��ӦͼƬ��Ϣ��
 * 
 * @author hyc
 */
package com.huiyuan.weixin.pojo.servermessage;

public class ImageMessage extends BaseMessage{
	//ͼƬ
	private Image image;

	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}
	
}
