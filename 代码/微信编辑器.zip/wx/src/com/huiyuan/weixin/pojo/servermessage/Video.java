/**
 * ��Ƶmodel
 * 
 * @author hyc
 */
package com.huiyuan.weixin.pojo.servermessage;

public class Video {
	//ý���ļ�ID
	private String MediaId;
	//����ͼ��ý��ID
	private String ThumbMediaId;
	
	public String getMediaId() {
		return MediaId;
	}
	public void setMediaId(String mediaId) {
		MediaId = mediaId;
	}
	public String getThumbMediaId() {
		return ThumbMediaId;
	}
	public void setThumbMediaId(String thumbMediaId) {
		ThumbMediaId = thumbMediaId;
	}
	
}
