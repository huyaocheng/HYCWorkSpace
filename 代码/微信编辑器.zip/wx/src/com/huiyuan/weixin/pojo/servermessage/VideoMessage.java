/**
 * ��Ӧ��Ƶ��Ϣ��
 * 
 * @author hyc
 */
package com.huiyuan.weixin.pojo.servermessage;

public class VideoMessage extends BaseMessage{
	//��Ƶ
	private Video video;

	public Video getVideo() {
		return video;
	}

	public void setVideo(Video video) {
		this.video = video;
	}
	
}
