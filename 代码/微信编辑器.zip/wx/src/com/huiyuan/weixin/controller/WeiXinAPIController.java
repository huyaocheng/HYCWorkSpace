package com.huiyuan.weixin.controller;

import java.io.Writer;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.huiyuan.core.util.RequestStream2StringUtil;
import com.huiyuan.weixin.process.message.ReqMessageProcess;
import com.huiyuan.weixin.util.WxCheckTools;

@RestController
@RequestMapping("/wx")
public class WeiXinAPIController {
	/**
	 * ΢�Ž�����֤����
	 * @param signature ΢�ż���ǩ��
	 * @param timestamp ʱ���
	 * @param nonce �����
	 * @param echostr ����ַ���
	 * @return
	 */
	@RequestMapping(value = "/API",produces="text/html;charset=UTF-8")
	public String API( @RequestParam Map<String, String> params,HttpServletRequest request){
		/*String signature = params.get("signature");
		String timestamp = params.get("timestamp");
		String nonce = params.get("nonce");
		String echostr = params.get("echostr");
		if(WxCheckTools.checkSignauer(signature, timestamp, nonce)){
			return ReqMessageProcess.handleMessage(request);
		}*/
		String requestXML = RequestStream2StringUtil.conver(request);
		System.out.println(requestXML);
		return ReqMessageProcess.handleMessage(requestXML);
	}
	
}
	

