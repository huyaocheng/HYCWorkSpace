package com.huiyuan.weixin.controller;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.WritableResource;
import org.springframework.stereotype.Controller;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.huiyuan.core.util.Global;
import com.huiyuan.core.util.HttpsUtil;
import com.huiyuan.core.util.PropertiesTools;
import com.huiyuan.core.util.WebRootPath;
import com.huiyuan.weixin.util.WxGlobal;
import com.huiyuan.weixin.util.WxInterfaceUtil;

@Controller
@RequestMapping("message")
public class MessageController {
	private String accessToken = WxInterfaceUtil.getAccessToken();
	@RequestMapping("news")
	public String newsList(){
		
		return "/view/jspBlock/addNews";
	}
	
	@RequestMapping(value = "addNews")
	public void addNews(String req){
		/***************************************��������ͼ����Ϣbegin****************************************/
		String requestUrl = WxGlobal.ADD_EVER_NEWS.replace("ACCESS_TOKEN", accessToken);
		net.sf.json.JSONObject jsonObject = HttpsUtil.httpsRequest(requestUrl, "POST", req);
		System.out.println(jsonObject.toString());
		/***************************************��������ͼ����Ϣend****************************************/
		
		/***************************************Ԥ��ͼ����Ϣbegin****************************************/
		/*String reqStr = "https://api.weixin.qq.com/cgi-bin/message/mass/preview?access_token="+WxInterfaceUtil.getAccessToken();
		String reqData = "{\"touser\":\"oF-KmwJXCqiRJ3j1uF0EsNY61O7U\",\"mpnews\":{\"media_id\":\"OLgHX0WJdnd9dZl6iC7WVXZWADuIN8nOVfZXXQWWpvw\"},\"msgtype\":\"mpnews\"}";
		net.sf.json.JSONObject json = HttpsUtil.httpsRequest(reqStr, "POST", reqData);
		System.out.println(json.toString());*/
		/***************************************Ԥ��ͼ����Ϣend****************************************/
	}
	@RequestMapping(value = "/upLoad")
	 public void upLoad(HttpServletRequest request,HttpServletResponse response) throws IllegalStateException, IOException {  
			//�ϴ��ļ�����
			String myFileName = null;
			 //�����ϴ�·��  
            String rootPath = WebRootPath.getPath();
            String path = rootPath + Global.UPLOAD_IMGPATH;
			//����һ��ͨ�õĶಿ�ֽ�����  
	        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(request.getSession().getServletContext());  
	        //�ж� request �Ƿ����ļ��ϴ�,���ಿ������  
	        if(multipartResolver.isMultipart(request)){  
	            //ת���ɶಿ��request    
	            MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest)request;  
	            //ȡ��request�е������ļ��Լ���ǩ����
	            Map<String, MultipartFile> map =multiRequest.getFileMap();
	            Set<String> set = map.keySet();
	            Iterator<String> key = set.iterator();
	            while(key.hasNext()){
	            	String keyName =  key.next();
	            	MultipartFile file = (MultipartFile) map.get(keyName);
	            	if(file != null){  
	                    //ȡ�õ�ǰ�ϴ��ļ����ļ�����  
	                    myFileName = file.getOriginalFilename(); 
	                    //������Ʋ�Ϊ����,˵�����ļ����ڣ�����˵�����ļ�������  
	                    if(myFileName.trim() !=""){  
	                        File fdir = new File(path);
	                        //�ж��ļ����Ƿ����,����������򴴽��ļ���
	                        if (!fdir.exists()) {
	                        	fdir.mkdir();
	                        }
	                        File localFile = new File(path +"/"+ myFileName);  
	                        file.transferTo(localFile);  
	                    }  
	                } 
	            }
	        }
	      //*****************************************��ý���ϴ�ͼƬ begin***************************************************
			WritableResource resource = new FileSystemResource(new File(path +"/"+ myFileName));
			MultiValueMap data = new LinkedMultiValueMap();
			data.add("media", resource);
			String urlString = WxGlobal.ADD_EVER_MATTER.replace("ACCESS_TOKEN", accessToken)+"&type=image";
			RestTemplate restTemplate = new RestTemplate();
			String result = restTemplate.postForObject(urlString, data, String.class);
			JSONObject jsonResult = new JSONObject(result);
			//****************************************��ý���ϴ�ͼƬ end*****************************************************
			String imgPath = Global.UPLOAD_IMGPATH +"/"+ myFileName;//�ϴ�ͼƬ����λ��
			jsonResult.put("imgPath", imgPath);
	        response.getWriter().write(jsonResult.toString());
	    } 
	
	
}
