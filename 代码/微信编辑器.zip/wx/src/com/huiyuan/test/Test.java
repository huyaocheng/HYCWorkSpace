package com.huiyuan.test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

import javax.script.Bindings;
import javax.script.Invocable;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Test {
	public static void main(String[] args) throws FileNotFoundException, ScriptException, NoSuchMethodException {
		/*//java��ȡ��ִ��js����
		ScriptEngine engine = new ScriptEngineManager().getEngineByName("javascript");
		Bindings bind = engine.createBindings();
		bind.put("factor",2);
		engine.setBindings(bind, ScriptContext.ENGINE_SCOPE);
		Scanner input = new Scanner(System.in);
		while(input.hasNextInt()){
			int first = input.nextInt();
			int sec = input.nextInt();
			System.out.println("����Ĳ����ǣ�"+first+","+sec);
			engine.eval(new FileReader("e:/model.js"));
			if(engine instanceof Invocable){
				Invocable in = (Invocable)engine;
				Double result = (Double)in.invokeFunction("formula", first,sec);
				System.out.print("��������"+result.intValue());
			}
		}*/
		System.out.println("10.5�Ľ���ֵ��"+Math.round(10.5));
		System.out.println("-10.5�Ľ���ֵ��"+Math.round(-10.5));
	}
}
