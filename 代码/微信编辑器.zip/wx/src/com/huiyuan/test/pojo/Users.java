package com.huiyuan.test.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="t_user")
public class Users {
	private Long userId;
	private String userSex;
	private String userName;
	private String passWord;
	private int age;
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq_user")
	@SequenceGenerator(name="seq_user",sequenceName="SEQ_USER",allocationSize=1)
	@Column(name="ID",unique=true,nullable=true)
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	@Column(name="SEX",length=2)
	public String getUserSex() {
		return userSex;
	}
	public void setUserSex(String userSex) {
		this.userSex = userSex;
	}
	@Column(name="NAME",length=20)
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Column(name="PASSWORD",length=20)
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	@Column(name="AGE",length=11)
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}
