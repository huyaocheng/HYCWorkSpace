package com.huiyuan.test.controller;

import java.io.File;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.WritableResource;
import org.springframework.stereotype.Controller;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.huiyuan.core.util.PropertiesTools;
import com.huiyuan.test.dao.UserDao;
import com.huiyuan.weixin.pojo.Menu.Button;
import com.huiyuan.weixin.pojo.Menu.ClickButton;
import com.huiyuan.weixin.pojo.Menu.ComplexButton;
import com.huiyuan.weixin.pojo.Menu.LocationButton;
import com.huiyuan.weixin.pojo.Menu.Menu;
import com.huiyuan.weixin.pojo.Menu.PictureButton;
import com.huiyuan.weixin.pojo.Menu.ScancodeButton;
import com.huiyuan.weixin.pojo.Menu.ViewButton;
import com.huiyuan.weixin.util.WxInterfaceUtil;
import com.huiyuan.weixin.util.WxMenuUtil;

@Controller
@RequestMapping("/hu")
public class UserController {
	@Resource(name = "userDao")
	UserDao userDao;
	
	@RequestMapping(value = "/menu")
	public String selectUser(){
		
		ClickButton but11 = new ClickButton();
		but11.setName("�����ťһ");
		but11.setKey("key1");
		but11.setType("click");
		ClickButton but12 = new ClickButton();
		but12.setName("�����ť��");
		but12.setKey("key2");
		but12.setType("click");
		
		//���ӱ�����http��ͷ������ᱨ40054����
		ViewButton but21 = new ViewButton();
		but21.setName("���Ӱ�ťһ");
		but21.setUrl("http://www.baidu.com/");
		but21.setType("view");
		ViewButton but22 = new ViewButton();
		but22.setName("���Ӱ�ť��");
		but22.setUrl("http://www.qq.com/");
		but22.setType("view");
		ViewButton but23 = new ViewButton();
		but23.setName("���Ӱ�ť��");
		but23.setUrl("http://oa.zhongruanruida.com/fDifferent/");
		but23.setType("view");
		
		ComplexButton cb = new ComplexButton();
		cb.setSub_button(new Button[]{});
		
		PictureButton but31 = new PictureButton();
		but31.setKey("pic1");
		but31.setName("ͼƬ��ť");
		but31.setType("pic_photo_or_album");
		but31.setComplexButton(cb);
		LocationButton but32 = new LocationButton();
		but32.setKey("loc1");
		but32.setName("������ť");
		but32.setType("location_select");
		ScancodeButton but33 = new ScancodeButton();
		but33.setKey("scan1");
		but33.setName("ɨ�밴ť");
		but33.setType("scancode_push");
		but33.setComplexButton(cb);
		
		ComplexButton mainBut1 = new ComplexButton();
		mainBut1.setName("�����ť");
		mainBut1.setSub_button(new Button[]{but11, but12});
		ComplexButton mainBut2 = new ComplexButton();
		mainBut2.setName("���Ӱ�ť");
		mainBut2.setSub_button(new Button[]{but21, but22, but23});
		ComplexButton mainBut3 = new ComplexButton();
		mainBut3.setName("���Ͱ�ť");
		mainBut3.setSub_button(new Button[]{but31, but32, but33});
		
		Menu menu = new Menu();
		menu.setButton(new Button[]{mainBut1, mainBut2, mainBut3});
		
		String accessToken = WxInterfaceUtil.getAccessToken();
		boolean result = WxMenuUtil.createMenu(menu, accessToken);
		System.out.println(result);
		return "success";
	}
	
	@RequestMapping(value = "/accessToken")
	public String accessToken(HttpServletRequest request){
		WxInterfaceUtil.getAccess_token(PropertiesTools.getKeyValue("appID"), PropertiesTools.getKeyValue("appsecret"));
		return "success";
	}
	
	public void test(){
		//*****************************************��ý���ϴ�ͼƬ begin***************************************************
		/*WritableResource resource = new FileSystemResource(new File("C:/Users/IBM_ADMIN/Desktop/a.jpg"));
		MultiValueMap data = new LinkedMultiValueMap();
		data.add("media", resource);
		// data.add("type", "image");
		// data.add("access_token", "M2brmyjO6xyUb42OZoeJJ0CWJtOXkVG6e1tAtjZG4AtcjG9mb6FCnocpC7uYeAi_WOOzI7IR14fSrvyCLErIvrjdmG2qhl8oHFimFLGg8LM");
		// RestTemplate restTemplate = new RestTemplate();
		// String result = restTemplate.postForObject("http://file.api.weixin.qq.com/cgi-bin/media/upload", data, String.class);
		 
		String tokenString = "M2brmyjO6xyUb42OZoeJJ0CWJtOXkVG6e1tAtjZG4AtcjG9mb6FCnocpC7uYeAi_WOOzI7IR14fSrvyCLErIvrjdmG2qhl8oHFimFLGg8LM";
		String urlString = "https://api.weixin.qq.com/cgi-bin/media/upload?access_token="+tokenString+"&type=image";
		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.postForObject(urlString, data, String.class);
		 
		System.out.println(result);*/
		//****************************************��ý���ϴ�ͼƬ end*****************************************************
		 
		 
		 
		//*****************************************������ȯ�ϴ� LOGO �ӿ� begin***************************************************
		WritableResource resource = new FileSystemResource(new File("C:/Users/IBM_ADMIN/Desktop/a.jpg"));
		MultiValueMap data = new LinkedMultiValueMap();
		data.add("buffer", resource);
		 
		String tokenString = "M2brmyjO6xyUb42OZoeJJ0CWJtOXkVG6e1tAtjZG4AtcjG9mb6FCnocpC7uYeAi_WOOzI7IR14fSrvyCLErIvrjdmG2qhl8oHFimFLGg8LM";
		String urlString = "https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token="+tokenString;
		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.postForObject(urlString, data, String.class);
		 
		System.out.println(result);
		//****************************************������ȯ�ϴ� LOGO �ӿ� end*****************************************************

	}
}
