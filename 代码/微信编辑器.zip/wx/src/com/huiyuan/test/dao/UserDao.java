package com.huiyuan.test.dao;

import javax.annotation.Resource;

import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.huiyuan.test.pojo.Users;
@Transactional
@Component("userDao")
public class UserDao {
	@Resource(name="hibernateTemplate")
	private HibernateTemplate templante;
	/*
	 *��ѯ����
	 */
	public Users getDate(Long id) {
		//Class c = User.getClass();
		Users u = (Users) templante.get("com.hu.pojo.Users", id);
		System.out.println(u);
		return u;
	}
}
