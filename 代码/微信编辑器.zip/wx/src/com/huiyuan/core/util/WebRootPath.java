/**
 * ����web��Ŀ��Ŀ¼���� ͨ��com.huiyuan.core.listener.AppServletContextListener.java ����
 * @author hyc
 */
package com.huiyuan.core.util;

public class WebRootPath {
	private static String path;
	private static String contextPath;

	public static String getPath() {
		return path;
	}

	public static void setPath(String p) {
		if (path == null) {
			path = p;
		}
	}

	public static String getContextPath() {
		return contextPath;
	}

	public static void setContextPath(String contextPath) {
		if (contextPath == null) {
			WebRootPath.contextPath = contextPath;
		}
	}

}
